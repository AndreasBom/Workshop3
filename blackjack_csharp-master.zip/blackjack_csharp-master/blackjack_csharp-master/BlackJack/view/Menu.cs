﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlackJack.view
{
    static class Menu
    {
        public enum MenuItems
        {
            Play,
            Hit, 
            Stand, 
            Quit, 
            NoAction
        }
    }
}
